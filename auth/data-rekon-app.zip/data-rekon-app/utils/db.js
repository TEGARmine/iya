const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://a:@cluster0.4a5ie.mongodb.net/0?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
});


// // Menambah satu data
// const contact1 = new Contact({
//     nama: 'Maulana',
//     nohp: '085765465786',
//     email: 'Maulana@gmail.com',
// });
// // simpan ke collection
// contact1.save().then((contact) => console.log(contact));